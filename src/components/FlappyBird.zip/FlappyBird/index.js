import { Fragment, useEffect, useRef, useState } from "react";
import "./styles.css";

const playerWidth = 100;
const playerHeight = 75;

const screenWidth = 1200;
const screenHeight = 600;
const gap = 200;

const getRandomNumber = (max) => {
    return Math.floor(Math.random() * max);
};

const FlappyBird = () => {
    const [charizardX, setCharizardX] = useState(100);
    const [charizardY, setCharizardY] = useState(
        (screenHeight / 2) - (playerHeight * 2)
    );
    const charizardRef = useRef(null);
    const [obstacles, setObstacles] = useState([]);

    const handleClick = (event) => {
        if(event.key === 'ArrowUp') {
            if(charizardRef.current.offsetTop - 100 < 0) {

            } else {
                setCharizardY(prev => prev - 50);
            }
        } 
    };

    const createObstacle = () => {
        const i = obstacles.length;
        const height1 = getRandomNumber(screenHeight - gap);
        const height2 = screenHeight - gap - height1;
        const obstacle = [
            {x: screenWidth, y: 0, h: height1, w: 100},
            {x: screenWidth, y: screenHeight - height2, h: height2, w: 100}
        ];
        setObstacles(_obstacles => [..._obstacles, obstacle]);
    };
    
    useEffect(() => {
        window.addEventListener('keydown', handleClick);
        return () => {
            window.removeEventListener('keydown', handleClick);
        };
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            if(charizardRef.current && charizardRef.current.offsetTop + charizardRef.current.clientHeight >= charizardRef.current.offsetParent.offsetTop + charizardRef.current.offsetParent.clientHeight) {

            } else {
                setCharizardY(prev => prev + 6);
            }
        }, 50);
        return () => {
            clearInterval(interval);
        };
    }, []);

    useEffect(() => {
        // createObstacle();
        const interval = setInterval(createObstacle, 2500);
        return () => {
            clearInterval(interval);
        };
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            setObstacles(_obstacles => {
                for(let i = 0; i < _obstacles.length; ++i) {
                    _obstacles[i][0].x -= 1;
                    _obstacles[i][1].x -= 1;
                }
                return [..._obstacles];
            });
        }, 10);
        return () => {
            clearInterval(interval);
        };
    }, []);

    return (
        <div className="flappy-bird-container">
            <div className="screen" style={{width: `${screenWidth}px`, height: `${screenHeight}px`,}}>
                <div
                    className="player"
                    style={{
                        width: `${playerWidth}px`,
                        height: `${playerHeight}px`,
                        top: `${charizardY}px`,
                        left: `${charizardX}px`,
                    }}
                    ref={charizardRef}
                >
                    <img src="/charizard.gif" alt="Charizard" />
                </div>
                {obstacles.map(obstacle => {
                    return (
                        <Fragment>
                            <img
                                src='/obstacle.png'
                                className='obstacle'
                                style={{
                                    top: obstacle[0].y,
                                    left: obstacle[0].x,
                                    height: obstacle[0].h,
                                    width: obstacle[0].w,
                                }}
                            />
                            <img
                                src='/obstacle.png'
                                className='obstacle'
                                style={{
                                    top: obstacle[1].y,
                                    left: obstacle[1].x,
                                    height: obstacle[1].h,
                                    width: obstacle[1].w,
                                    transform: 'rotate(180deg)'
                                }}
                            />
                        </Fragment>
                    );
                })}
            </div>
            <div className="options"></div>
        </div>
    );
};

export default FlappyBird;
